package lab.ch01;

public class NPEtest {
	//파라미터 자리를 통해서 초기화가 호출될 때 일어남
	//이 때 null일수도 있다 생각고려
	void methodA(String temp) {
		System.out.println("methodA호출 성공");
		System.out.println(temp.length());
	}
	public static void main(String[] args) {
		String msg = "Hello";
		System.out.println(msg.length()); //5
		//length() 동사형은 문자열의 길이를 반환하고
		//length명사형은 배열의 크기를 반환함
		System.out.println("Hello".length()); //5
		//String name = null;//초기화하는데 null을 사용함.
		//System.out.println(name.length());
		//insert here
		NPEtest epe = new NPEtest();
		epe.methodA(null);

	}

}

